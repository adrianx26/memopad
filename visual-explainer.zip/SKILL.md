---
name: visual-explainer
description: >-
  Create visual explanations and diagrams for complex software systems, codebases, and concepts.
  This skill generates ASCII diagrams, flowcharts, architecture visualizations, and concept maps
  to help understand and communicate technical systems. Use when explaining software architecture,
  data flows, system relationships, or complex code structures.
license: MIT
metadata:
  category: documentation
  tags:
    - visualization
    - diagrams
    - explanation
    - architecture
    - documentation
---

# Visual Explainer

Transform complex technical concepts into clear visual representations using ASCII art,
structured diagrams, and hierarchical visualizations.

## When to Use

Activate this skill when:

- Explaining software architecture or system design
- Visualizing data flows and component interactions
- Creating concept maps for knowledge domains
- Documenting codebase structure and relationships
- Presenting complex technical information visually

## Visualization Types

### 1. Architecture Diagrams

Show high-level system structure with components and their relationships.

Format:

```
┌─────────────────────────────────────────────────────────────┐
│                      SYSTEM NAME                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────┐      ┌──────────┐      ┌──────────┐          │
│  │ Component│──────│ Component│──────│ Component│          │
│  │    A     │      │    B     │      │    C     │          │
│  └────┬─────┘      └────┬─────┘      └────┬─────┘          │
│       │                 │                 │                │
│       └─────────────────┴─────────────────┘                │
│                         │                                   │
│                   ┌─────┴─────┐                            │
│                   │  Shared   │                            │
│                   │  Service  │                            │
│                   └───────────┘                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 2. Data Flow Diagrams

Illustrate how data moves through a system.

Format:

```
Input → [Process A] → [Process B] → [Process C] → Output
         │              │              │
         ↓              ↓              ↓
      [Store 1]     [Store 2]     [Store 3]
```

### 3. Hierarchy Trees

Display hierarchical relationships (file systems, class hierarchies, org charts).

Format:

```
Root/
├── Branch A/
│   ├── Leaf 1
│   └── Leaf 2
├── Branch B/
│   ├── Leaf 3
│   └── Leaf 4
└── Branch C/
    └── Leaf 5
```

### 4. Component Relationship Maps

Show connections between system components.

Format:

```
        ┌─────────┐
        │   API   │
        └────┬────┘
             │
    ┌────────┼────────┐
    ↓        ↓        ↓
┌───────┐ ┌───────┐ ┌───────┐
│Service│ │Service│ │Service│
│   1   │ │   2   │ │   3   │
└───┬───┘ └───┬───┘ └───┬───┘
    │         │         │
    └─────────┼─────────┘
              ↓
         ┌─────────┐
         │ Database│
         └─────────┘
```

## Usage Workflow

### Step 1: Analyze the Subject

Understand what needs to be visualized:

- What are the main components?
- How do they relate to each other?
- What are the key data flows or interactions?
- What level of detail is appropriate?

### Step 2: Choose the Right Visualization

Select the format that best represents the information:

- **Architecture Diagram**: For system structure and boundaries
- **Data Flow**: For processes and transformations
- **Hierarchy Tree**: For nested or parent-child relationships
- **Component Map**: For interconnected systems

### Step 3: Create the Visualization

Build the diagram using:

- Box-drawing characters (┌─┐│└┘) for structure
- Arrows (→ ← ↑ ↓) for direction
- Labels for clarity
- Consistent spacing for readability

### Step 4: Add Context

Include explanatory text:

- Title and purpose
- Legend for symbols
- Key insights or patterns
- Usage notes

## Best Practices

1. **Keep it Simple**: Show only essential components
2. **Be Consistent**: Use uniform symbols and spacing
3. **Label Clearly**: Every element should be identifiable
4. **Show Relationships**: Focus on connections, not just components
5. **Layer Information**: Start with high-level, add detail as needed

## Example: MVC Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    MVC Application                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐      ┌──────────────┐      ┌──────────┐  │
│  │   View       │◄─────│  Controller  │─────►│  Model   │  │
│  │  (UI Layer)  │      │  (Logic)     │      │ (Data)   │  │
│  └──────┬───────┘      └──────┬───────┘      └────┬─────┘  │
│         │                     │                   │        │
│         │  Renders            │  Updates          │        │
│         │                     │                   │        │
│         ▼                     ▼                   ▼        │
│  ┌──────────────┐      ┌──────────────┐      ┌──────────┐  │
│  │  User        │      │  Business    │      │ Database │  │
│  │  Interface   │      │  Logic       │      │          │  │
│  └──────────────┘      └──────────────┘      └──────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Integration with Code Analysis

When analyzing codebases:

1. Identify entry points and main modules
2. Map imports and dependencies
3. Trace data transformation paths
4. Highlight key architectural patterns

## Output Format

Always structure visual explanations with:

1. Brief textual overview
2. The ASCII diagram
3. Component descriptions
4. Key relationships explanation
