﻿"""CLI tools for memopad"""
