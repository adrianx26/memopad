﻿"""MCP server command with streamable HTTP transport."""

# -----------------------------------------------------------------------------
# Windows Event Loop Fix (MUST be before any other imports)
# -----------------------------------------------------------------------------
# On Windows, anyio auto-selects 'winloop' (Windows port of uvloop) as the
# event loop backend, which has known issues with stdio operations causing:
# - "IndexError: pop from an empty deque" during event loop cleanup
# - Crashes in run_forever -> _run_once -> popleft
#
# This fix MUST be applied before any imports that might trigger anyio to be
# imported (directly or indirectly), as anyio caches its backend selection on
# first import.
#
# The fix uses multiple approaches:
# 1. Set ANYIO_BACKEND=asyncio to force anyio to use standard asyncio
# 2. Set WindowsSelectorEventLoopPolicy for better stdio/pipe stability
# 3. Create a fake winloop module that raises ImportError to prevent anyio
#    from using winloop even if it's installed
# -----------------------------------------------------------------------------

import os
import sys

if os.name == "nt":  # Windows-specific fix
    # Force anyio to use standard asyncio backend instead of winloop
    # This must be set before anyio is imported
    os.environ.setdefault("ANYIO_BACKEND", "asyncio")

    # Force SelectorEventLoopPolicy which is more stable for stdio/pipes on Windows
    # This fixes the crash seen in run_forever -> _run_once -> popleft
    import asyncio
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    # Create a fake winloop module that raises ImportError when any attribute is accessed
    # This prevents anyio from using winloop even if it's installed
    class _FakeWinloop:
        """Fake module that raises ImportError for any attribute access."""
        def __getattr__(self, name):
            raise ImportError(f"winloop is disabled on this system due to stdio compatibility issues")
    
    # Install the fake module before anyio can import the real one
    sys.modules["winloop"] = _FakeWinloop()

# -----------------------------------------------------------------------------
# Now safe to import other modules (anyio will be imported through these)
# -----------------------------------------------------------------------------

import typer
from typing import Optional

from memopad.cli.app import app
from memopad.config import ConfigManager, init_mcp_logging

# Import mcp instance (has lifespan that handles initialization and file sync)
from memopad.mcp.server import mcp as mcp_server  # pragma: no cover

# Import mcp tools to register them
import memopad.mcp.tools  # noqa: F401  # pragma: no cover

# Import prompts to register them
import memopad.mcp.prompts  # noqa: F401  # pragma: no cover
from loguru import logger


@app.command()
def mcp(
    transport: str = typer.Option("stdio", help="Transport type: stdio, streamable-http, or sse"),
    host: str = typer.Option(
        "0.0.0.0", help="Host for HTTP transports (use 0.0.0.0 to allow external connections)"
    ),
    port: int = typer.Option(8000, help="Port for HTTP transports"),
    path: str = typer.Option("/mcp", help="Path prefix for streamable-http transport"),
    project: Optional[str] = typer.Option(None, help="Restrict MCP server to single project"),
):  # pragma: no cover
    """Run the MCP server with configurable transport options.

    This command starts an MCP server using one of three transport options:

    - stdio: Standard I/O (good for local usage)
    - streamable-http: Recommended for web deployments (default)
    - sse: Server-Sent Events (for compatibility with existing clients)

    Initialization, file sync, and cleanup are handled by the MCP server's lifespan.
    """

    # Initialize logging for MCP (file only, stdout breaks protocol)
    init_mcp_logging()

    # Validate and set project constraint if specified
    if project:
        config_manager = ConfigManager()
        project_name, _ = config_manager.get_project(project)
        if not project_name:
            typer.echo(f"No project found named: {project}", err=True)
            raise typer.Exit(1)

        # Set env var with validated project name
        os.environ["MEMOPAD_MCP_PROJECT"] = project_name
        logger.info(f"MCP server constrained to project: {project_name}")

    # Run the MCP server (blocks)
    # Lifespan handles: initialization, migrations, file sync, cleanup
    logger.info(f"Starting MCP server with {transport.upper()} transport")

    if transport == "stdio":
        mcp_server.run(
            transport=transport,
        )
    elif transport == "streamable-http" or transport == "sse":
        mcp_server.run(
            transport=transport,
            host=host,
            port=port,
            path=path,
            log_level="INFO",
        )
