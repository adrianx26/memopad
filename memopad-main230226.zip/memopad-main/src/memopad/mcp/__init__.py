﻿"""MCP server for memopad."""
